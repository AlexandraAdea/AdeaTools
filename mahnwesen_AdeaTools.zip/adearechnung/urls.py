"""
URL-Konfiguration für AdeaRechnung - Fakturierung und Rechnungserstellung.
"""
from django.urls import path
from . import views, mahn_views
from adeazeit.views import mark_as_invoiced

app_name = "adearechnung"

urlpatterns = [
    # Kundenübersicht / Fakturierung
    path("", views.ClientTimeSummaryView.as_view(), name="client-summary"),
    
    # Verrechnung markieren
    path("mark-invoiced/", mark_as_invoiced, name="mark-invoiced"),
    
    # Rechnungserstellung
    path("create-invoice/", views.CreateInvoiceView.as_view(), name="create-invoice"),
    
    # Rechnungsliste
    path("invoices/", views.InvoiceListView.as_view(), name="invoice-list"),
    
    # Rechnungsdetail
    path("invoices/<int:pk>/", views.InvoiceDetailView.as_view(), name="invoice-detail"),
    path("invoices/<int:pk>/manual-items/add/", views.InvoiceManualItemCreateView.as_view(), name="invoice-manual-item-create"),
    path("invoices/<int:pk>/manual-items/<int:item_pk>/update/", views.InvoiceManualItemUpdateView.as_view(), name="invoice-manual-item-update"),
    path("invoices/<int:pk>/manual-items/<int:item_pk>/delete/", views.InvoiceManualItemDeleteView.as_view(), name="invoice-manual-item-delete"),
    path("invoices/<int:pk>/update-payment/", views.InvoiceUpdatePaymentView.as_view(), name="invoice-update-payment"),
    path("invoices/<int:pk>/update-discount/", views.InvoiceUpdateDiscountView.as_view(), name="invoice-update-discount"),
    path("invoices/<int:pk>/reset-billing/", views.InvoiceResetBillingView.as_view(), name="invoice-reset-billing"),
    path("invoices/<int:pk>/delete/", views.InvoiceDeleteView.as_view(), name="invoice-delete"),
    
    # PDF-Export
    path("invoices/<int:pk>/pdf/", views.InvoicePDFView.as_view(), name="invoice-pdf"),

    # Akonto-Abzug auf bestehender Rechnung (z.B. Schlussrechnung)
    path("invoices/<int:pk>/akonto-abzug/", views.InvoiceAddAkontoDeductionView.as_view(), name="invoice-akonto-deduction"),

    # Akonto-Pläne
    path("akonto/", views.AkontoPlanListView.as_view(), name="akonto-plan-list"),
    path("akonto/neu/", views.AkontoPlanCreateView.as_view(), name="akonto-plan-create"),
    path("akonto/<int:pk>/bearbeiten/", views.AkontoPlanUpdateView.as_view(), name="akonto-plan-update"),
    path("akonto/<int:pk>/rechnung-erstellen/", views.GenerateAkontoInvoiceView.as_view(), name="akonto-generate-invoice"),

    # Mahnwesen
    path("mahnwesen/", mahn_views.MahnlaufView.as_view(), name="mahnlauf"),
    path("mahnwesen/<int:pk>/pdf/", mahn_views.MahnungPDFView.as_view(), name="mahnung-pdf"),
    path("mahnwesen/<int:pk>/versendet/", mahn_views.MahnungVersendetView.as_view(), name="mahnung-versendet"),
    path("invoices/<int:pk>/mahnsperre/", mahn_views.InvoiceMahnsperreView.as_view(), name="invoice-mahnsperre"),
]



